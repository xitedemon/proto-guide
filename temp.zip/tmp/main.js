
// comment

(function(){
	console.log("sdf");
})(jQuery);


var globalVar;
function funcName(firstLongName, anotherLongName) {
    var myVariable = firstLongName +  anotherLongName;
}



/*

if(typeof foo == "undefined"){
	console.log("sdf");
}


var q = Math.floor(a/b);


function Object(){
	file: {}
}


Object.prototype.cool = function() {
	console.log("fsdf");
};


// Dead Code
function temp() {
    return 1;
    var a = 2; // Dead Code
}
function temp() {
    var a = 2;
    if (a > 3) {
         return 3; // Dead Code
    }
}

*/