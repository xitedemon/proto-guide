
(function(){
	console.log('Short Method : jQuery Ready [Not Recommended]');
});
$(function(){
	console.log('Short Method : jQuery Ready [Recommended]');
});
(function($){
	console.log('Another Ready Short Method');
})(jQuery);
$(document).ready(function(){
	console.log('This code executes when document is ready/fully loaded');
	console.log('Executes when HTML-Document is loaded and DOM is ready.');
});
jQuery(document).ready(function(){
	console.log('$ is Alias of jQuery.');
	console.log('This code executes when document is ready/fully loaded');
	console.log('Executes when HTML-Document is loaded and DOM is ready.');
});
$(window).on("load", function() {
	console.log('Executes when complete page is fully loaded, including all frames, objects and images');
});

(function(){
	console.log('Short Method : jQuery Ready [Not Recommended]');
});
$(function(){
	console.log('Short Method : jQuery Ready [Recommended]');
});
(function($){
	console.log('Another Ready Short Method');
})(jQuery);
$(document).ready(function(){
	console.log('This code executes when document is ready/fully loaded');
	console.log('Executes when HTML-Document is loaded and DOM is ready.');
});
jQuery(document).ready(function(){
	console.log('$ is Alias of jQuery.');
	console.log('This code executes when document is ready/fully loaded');
	console.log('Executes when HTML-Document is loaded and DOM is ready.');
});
$(window).on("load", function() {
	console.log('Executes when complete page is fully loaded, including all frames, objects and images');
});