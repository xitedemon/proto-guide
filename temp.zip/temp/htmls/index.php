<?php
$x = '<b> This is Bold Tag </b>    <i>Inline tag</i>';
?>
echo '<b> This is Bold Tag </b>    



<i>Inline tag</i>';


?>
<!DOCTYPE html>
<html>
<head>
	<title>This is html page.</title>
</head>
<body>



<h2>This is headline</h2>



</body>
</html>