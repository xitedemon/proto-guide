console.log("Hello Too");

console.log("Cool");