class Game {
  name = 'Violin Charades'
}
const myGame = new Game()