# Installation
> `npm install --save @types/validator`

# Summary
This package contains type definitions for validator.js (https://github.com/validatorjs/validator.js).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/validator.

### Additional Details
 * Last updated: Tue, 07 Apr 2020 20:54:46 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [tgfjt](https://github.com/tgfjt), [Ilya Mochalov](https://github.com/chrootsu), [Ayman Nedjmeddine](https://github.com/IOAyman), [Louay Alakkad](https://github.com/louy), [Kacper Polak](https://github.com/kacepe), [Bonggyun Lee](https://github.com/deptno), [Naoto Yokoyama](https://github.com/builtinnya), [Philipp Katz](https://github.com/qqilihq), [Jace Warren](https://github.com/keatz55), [Munif Tanjim](https://github.com/MunifTanjim), and [Vlad Poluch](https://github.com/vlapo).
