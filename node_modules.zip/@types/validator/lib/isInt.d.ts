import validator from '../';
export type IsIntOptions = validator.IsIntOptions;
export default validator.isInt;
