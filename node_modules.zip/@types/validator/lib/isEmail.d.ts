import validator from '../';
export type IsEmailOptions = validator.IsEmailOptions;
export default validator.isEmail;
