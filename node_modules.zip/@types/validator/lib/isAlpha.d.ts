import validator from '../';
export type AlphaLocale = validator.AlphaLocale;
export default validator.isAlpha;
