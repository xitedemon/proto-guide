import validator from '../';
export default validator.isRFC3339;
