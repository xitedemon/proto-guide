import validator from '../';
export type IsURLOptions = validator.IsURLOptions;
export default validator.isURL;
