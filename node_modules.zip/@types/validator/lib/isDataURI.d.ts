import validator from '../';
export default validator.isDataURI;
