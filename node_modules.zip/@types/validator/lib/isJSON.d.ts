import validator from '../';
export default validator.isJSON;
