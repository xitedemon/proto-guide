import validator from '../';
export type IsISO8601Options = validator.IsISO8601Options;
export default validator.isISO8601;
