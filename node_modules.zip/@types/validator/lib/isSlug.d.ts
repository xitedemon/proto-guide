import validator from '../';
export default validator.isSlug;
