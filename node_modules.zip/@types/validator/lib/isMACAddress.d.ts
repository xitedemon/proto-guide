import validator from '../';
export type IsMACAddressOptions = validator.IsMACAddressOptions;
export default validator.isMACAddress;
