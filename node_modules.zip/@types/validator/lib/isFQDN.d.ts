import validator from '../';
export type IsFQDNOptions = validator.IsFQDNOptions;
export default validator.isFQDN;
