import validator from '../';
export type AlphanumericLocale = validator.AlphanumericLocale;
export default validator.isAlphanumeric;
