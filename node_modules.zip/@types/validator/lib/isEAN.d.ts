import validator from '../';
export default validator.isEAN;
