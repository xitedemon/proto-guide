import validator from '../';
export type IsLengthOptions = validator.IsLengthOptions;
export default validator.isLength;
