import validator from '../';
export default validator.toInt;
