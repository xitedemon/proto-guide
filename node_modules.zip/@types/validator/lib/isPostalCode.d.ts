import validator from '../';
export type PostalCodeLocale = validator.PostalCodeLocale;
export default validator.isPostalCode;
